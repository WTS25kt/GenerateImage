# arial.ttf

Arial font file to recover missing fonts for FL Studio.

1. Download the arial.ttf from this repository.
2. Drag and drop the font file into `/Library/Application Support/Image-Line/Shared/Artwork/Fonts` and `/Library/Fonts`
3. Restart the FL Studio

